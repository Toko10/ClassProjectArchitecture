from flask import Flask, render_template

app = Flask(__name__)

architecture = [
    {"id": 1, "title": "Greek", "img": "08.png"},
    {"id": 2, "title": "Russian", "img": "300px-Basil-cathedral-morning.jpg"},
    {"id": 3, "title": "Georgian", "img": "d0b3d0b0d181d0bfd180d0b0_d186d0b5d180d0bad0bed0b2d18c_d181d0b2d18fd182d0bed0b9_d09dd0b8d0bdd18b_1_l (1).png"},
    {"id": 3, "title": "Japanese", "img": "Images (2).png"},
    {"id": 3, "title": "Italian", "img": "Saint-Peters-Basilica-20230308.jpg"},
    {"id": 3, "title": "Spanish", "img": "1000_F_57942409_Mjq2HvhfvKa1GCIHvQaobfaERy3lhmbt.jpg"},
    {"id": 3, "title": "French", "img": "view-rooftops-paris-observation-deck-view-rooftops-paris-observation-deck-beautiful-blue-sky-211275171.png"},
    {"id": 3, "title": "Egyptian", "img": "pyramids-giza-egypt-cairo-general-view-plateau-left-pyramid-menkaure-mykerinos-khafre-chephren-33534064.png"}
]


@app.route("/")
def home():
    return render_template("index.html", arc=architecture)


@app.route("/login")
def login():
    return render_template("login.html")


@app.route("/about")
def about():
    return render_template("about.html")


@app.route("/architecture")
def arch1():
    return render_template("arch1.html", arc=architecture)


@app.route("/register")
def register():
    return render_template("register.html")


app.run(debug=True)